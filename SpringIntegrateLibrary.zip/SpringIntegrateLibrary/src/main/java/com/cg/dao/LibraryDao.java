package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.model.Book;
import com.cg.model.Library;

public class LibraryDao implements IlibraryDao {
	
	private static EntityManagerFactory mag = Persistence.createEntityManagerFactory("Jpa-servletdemo");
	private static EntityManager em = mag.createEntityManager();
   
        @Override
	public void addBook(Library lib) {
		em.getTransaction().begin();
		em.persist(lib);
		em.getTransaction().commit();
	}
	
        @Override
	public Library getLibrary(String libraryId) {
		  return em.find(Library.class,libraryId); 
        }
	 
        @Override
        public Book getBookbyId(String bookId) { 
		  return em.find(Book.class,bookId); 
         }
			 
	 @Override 
	 public void deleteBook(String bookId) {
	 em.getTransaction().begin(); 
	 Book bo = getBookbyId(bookId); 
	 em.remove(bo);
	 em.getTransaction().commit();
		
	}

        @Override
        public Book updateBookData(String id, String bookname, String auth, String publi) {
		Book bo = getBookbyId(id);
		em.getTransaction().begin();
	        bo.setBookName(bookname);
		bo.setAuthor(auth);
		bo.setPublisher(publi);
		em.getTransaction().commit();
		return bo;
	}
	
}
